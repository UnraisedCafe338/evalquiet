<?php
$host = 'localhost';
$dbname = 'evaluation_quiet';
$user = 'admin';
$pass = 'admin';


$connection = new mysqli($host, $user, $pass, $dbname);

?>